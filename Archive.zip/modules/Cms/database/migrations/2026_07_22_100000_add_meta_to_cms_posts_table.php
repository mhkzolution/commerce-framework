<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('cms_posts', function (Blueprint $table): void {
            $table->json('meta')->nullable()->after('published_at');
        });
    }

    public function down(): void
    {
        Schema::table('cms_posts', function (Blueprint $table): void {
            $table->dropColumn('meta');
        });
    }
};
